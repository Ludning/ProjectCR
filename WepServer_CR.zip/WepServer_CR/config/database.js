// ./config/database.js

//mysql을 접근할 때 사용할 DB설정 파일

//host : 접근할 DB의 host(ip)
//user : 접근할 DB의 userID
//password : 접근할 userID에 등록된 패스워드
//database : 접근할 DB명

module.exports = {
    host     : 'localhost',
    user     : 'root',
    password : '1234',
    database : 'test'
  };


//module.exports는 객체 참조로 require() 호출을 하면 받는 값이다. 
//그래서 ./config/database.js를 require로 호출하면 해당 값들을 받게 된다.