//#####################################DB
const mysql = require('mysql');

//db접근 설정 파일을 변수에 저장
const dbconfig = require('./config/database.js');
const connection = mysql.createConnection(dbconfig);

// 데이터베이스 연결
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MariaDB database:', err.stack);
        return;
    }
    console.log('Connected to MariaDB database as ID', connection.threadId);
});

// Node.js 애플리케이션이 종료될 때 연결 해제
process.on('SIGINT', () => {
    connection.end();
    console.log('MariaDB connection ended.');
    process.exit();
});


//#####################################WepServer
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.post('/player', (req, res) => {
    const { id, password } = req.body;
    console.log(req.body);
    // 데이터베이스에서 id와 password 확인
    connection.query('SELECT U_NickName, U_CharacterData, U_Level, U_Exp FROM player WHERE U_Id = ? AND U_Password = ?', [id, password], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        // 결과가 없으면 로그인 실패 처리
        if (results.length === 0) {
            res.status(401).json({ error: 'Invalid credentials' });
            return;
        }

        // 로그인 성공 시 클라이언트에게 데이터 전송
        const userData = results[0]; // 첫 번째 행의 데이터 사용
        res.json({
            nickname: userData.U_NickName,
            character: userData.U_CharacterData,
            level: userData.U_Level,
            exp: userData.U_Exp
        });
    });
});
app.post('/equipment', (req, res) => {
    const userId = req.body.id;
    console.log(req.body);

    // 데이터베이스에서 userId에 해당하는 아이템 조회
    connection.query('SELECT SlotId, ItemId, ArchetypeId, SpecificityId FROM equipment WHERE U_Id = ?', [userId], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        // 조회 결과가 없으면 빈 배열 반환
        if (results.length === 0) {
            res.json([]);
            return;
        }

        let equipmentData = {};
        results.forEach((row) => {
            equipmentData[row.SlotId] = {
                index: row.ItemId,
                archetypeID: row.ArchetypeId,
                specificityID: row.SpecificityId
            };
        });
        console.log(equipmentData);

        // 조회 결과를 클라이언트에게 JSON 형식으로 반환
        res.json(equipmentData);
    });
});
app.post('/inventory', (req, res) => {
    const userId = req.body.id;
    console.log(req.body);

    // 데이터베이스에서 userId에 해당하는 아이템 조회
    connection.query('SELECT SlotId, ItemId, ArchetypeId, SpecificityId FROM inventory WHERE U_Id = ?', [userId], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        // 조회 결과가 없으면 빈 배열 반환
        if (results.length === 0) {
            res.json([]);
            return;
        }

        let inventoryData = {};
        results.forEach((row) => {
            inventoryData[row.SlotId] = {
                index: row.ItemId,
                archetypeID: row.ArchetypeId,
                specificityID: row.SpecificityId
            };
        });
        console.log(inventoryData);

        // 조회 결과를 클라이언트에게 JSON 형식으로 반환
        res.json(inventoryData);
    });
});
app.post('/moveItem', (req, res) => {
    const { userId, fromSlotType, fromSlotId, toSlotType, toSlotId } = req.body;

    let checkFromQuery;
    let checkToQuery;
    let deleteQuery;
    let insertQuery;

    if (fromSlotType === "Inventory" && toSlotType === "Inventory") {
        // inventory에서 inventory로 옮길 때
        checkFromQuery = 'SELECT * FROM inventory WHERE U_Id = ? AND SlotId = ?';
        checkToQuery = 'SELECT * FROM inventory WHERE U_Id = ? AND SlotId = ?';
        deleteQuery = 'DELETE FROM inventory WHERE U_Id = ? AND SlotId = ?';
        insertQuery = 'INSERT INTO inventory (U_Id, SlotId, ItemId, ArchetypeId, SpecificityId) VALUES (?, ?, ?, ?, ?)';
    } else if (fromSlotType === "Inventory" && toSlotType === "Equipment") {
        // inventory에서 equipment로 옮길 때
        checkFromQuery = 'SELECT * FROM inventory WHERE U_Id = ? AND SlotId = ?';
        checkToQuery = 'SELECT * FROM equipment WHERE U_Id = ? AND SlotId = ?';
        deleteQuery = 'DELETE FROM inventory WHERE U_Id = ? AND SlotId = ?';
        insertQuery = 'INSERT INTO equipment (U_Id, SlotId, ItemId, ArchetypeId, SpecificityId) VALUES (?, ?, ?, ?, ?)';
    } else if (fromSlotType === "Equipment" && toSlotType === "Inventory") {
        // equipment에서 inventory로 옮길 때
        checkFromQuery = 'SELECT * FROM equipment WHERE U_Id = ? AND SlotId = ?';
        checkToQuery = 'SELECT * FROM inventory WHERE U_Id = ? AND SlotId = ?';
        deleteQuery = 'DELETE FROM equipment WHERE U_Id = ? AND SlotId = ?';
        insertQuery = 'INSERT INTO inventory (U_Id, SlotId, ItemId, ArchetypeId, SpecificityId) VALUES (?, ?, ?, ?, ?)';
    } else if (fromSlotType === "Equipment" && toSlotType === "Equipment") {
        // equipment에서 equipment로 옮길 때
        checkFromQuery = 'SELECT * FROM equipment WHERE U_Id = ? AND SlotId = ?';
        checkToQuery = 'SELECT * FROM equipment WHERE U_Id = ? AND SlotId = ?';
        deleteQuery = 'DELETE FROM equipment WHERE U_Id = ? AND SlotId = ?';
        insertQuery = 'INSERT INTO equipment (U_Id, SlotId, ItemId, ArchetypeId, SpecificityId) VALUES (?, ?, ?, ?, ?)';
    } else {
        res.status(400).json({ error: 'Invalid fromSlotType or toSlotType' });
        return;
    }

    connection.query(checkFromQuery, [userId, fromSlotId], (checkFromErr, checkFromResults) => {
        if (checkFromErr) {
            console.error('Error executing from slot query:', checkFromErr);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        if (checkFromResults.length === 0) {
            res.status(400).json({ error: 'Item not found in source slot' });
            return;
        }

        connection.query(checkToQuery, [userId, toSlotId], (checkToErr, checkToResults) => {
            if (checkToErr) {
                console.error('Error executing to slot query:', checkToErr);
                res.status(500).json({ error: 'Internal server error' });
                return;
            }

            if (checkToResults.length > 0) {
                res.status(400).json({ error: 'Target slot already occupied' });
                return;
            }

            const item = checkFromResults[0];
            connection.beginTransaction((transErr) => {
                if (transErr) {
                    res.status(500).json({ error: 'Transaction error' });
                    return;
                }

                connection.query(deleteQuery, [userId, fromSlotId], (deleteErr, deleteResults) => {
                    if (deleteErr) {
                        return connection.rollback(() => {
                            console.error('Error executing delete query:', deleteErr);
                            res.status(500).json({ error: 'Internal server error' });
                        });
                    }

                    connection.query(insertQuery, [userId, toSlotId, item.ItemId, item.ArchetypeId, item.SpecificityId], (insertErr, insertResults) => {
                        if (insertErr) {
                            return connection.rollback(() => {
                                console.error('Error executing insert query:', insertErr);
                                res.status(500).json({ error: 'Internal server error' });
                            });
                        }

                        connection.commit((commitErr) => {
                            if (commitErr) {
                                return connection.rollback(() => {
                                    console.error('Error committing transaction:', commitErr);
                                    res.status(500).json({ error: 'Transaction commit error' });
                                });
                            }

                            res.status(200).json({ message: 'Item moved successfully' });
                        });
                    });
                });
            });
        });
    });
});

// // 예시: GET 요청에 대한 핸들러
// app.get('/players', (req, res) => {
//     connection.query('SELECT * FROM players', (err, results) => {
//         if (err) {
//             console.error('Error executing query:', err);
//             res.status(500).json({ error: 'Internal server error' });
//             return;
//         }
//         res.json(results);
//     });
// });

// // 예시: POST 요청에 대한 핸들러
// app.post('/players', (req, res) => {
//     const { playerId, playerName } = req.body;

//     // 예시: 데이터베이스에 삽입 쿼리 실행
//     connection.query('INSERT INTO players (id, name) VALUES (?, ?)', [playerId, playerName], (err, result) => {
//         if (err) {
//             console.error('Error executing query:', err);
//             res.status(500).json({ error: 'Internal server error' });
//             return;
//         }
//         res.json({ message: 'Player added successfully', playerId: playerId });
//     });
// });


//Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
