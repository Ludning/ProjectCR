// ./middleware.js

//모듈들을 변수에 저장
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

//db접근 설정 파일을 변수에 저장
const dbconfig = require('./config/database.js');
const connection = mysql.createConnection(dbconfig);


//express객체를 생성한 뒤, 
//express의 set() 메서드로 배포할 port를 원하는 포트로 지정한다.
//그다음 listen()메서드로 서버를 실행 시켜준다.
//get()메서드로 설정된 포트 번호를 가져올 수 있다.
const app = express();

app.set('port',  3306);

app.listen(app.get('port'), () => {
    console.log('Express server listening on port ' + app.get('port'));
});


// 요청 본문을 JSON 형식으로 파싱
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// GET 요청 처리 예제
app.get('/', (req, res) => {
    res.send('Hello World');
});

// // GET 요청으로 데이터베이스에서 모든 사용자 목록 가져오기
// app.get('/users', (req, res) => {
//     const query = 'SELECT * FROM users';
//     connection.query(query, (err, results) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send('Internal Server Error');
//             return;
//         }
//         res.json(results);
//     });
// });

// // POST 요청으로 새로운 사용자 추가하기
// app.post('/users', (req, res) => {
//     const { name, age } = req.body;
//     const query = 'INSERT INTO users (name, age) VALUES (?, ?)';
//     connection.query(query, [name, age], (err, results) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send('Internal Server Error');
//             return;
//         }
//         res.status(201).send('User added successfully');
//     });
// });

// // PUT 요청으로 사용자 정보 수정하기
// app.put('/users/:id', (req, res) => {
//     const { id } = req.params;
//     const { name, age } = req.body;
//     const query = 'UPDATE users SET name = ?, age = ? WHERE id = ?';
//     connection.query(query, [name, age, id], (err, results) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send('Internal Server Error');
//             return;
//         }
//         res.send('User updated successfully');
//     });
// });

// // DELETE 요청으로 사용자 삭제하기
// app.delete('/users/:id', (req, res) => {
//     const { id } = req.params;
//     const query = 'DELETE FROM users WHERE id = ?';
//     connection.query(query, [id], (err, results) => {
//         if (err) {
//             console.error(err);
//             res.status(500).send('Internal Server Error');
//             return;
//         }
//         res.send('User deleted successfully');
//     });
// });

// // 에러 핸들링 미들웨어
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).send('Something went wrong!');
// });

// // 서버 실행
// app.listen(app.get('port'), () => {
//     console.log('Express server listening on port ' + app.get('port'));
// });


// 모든 사용자 정보 출력
app.get('/all-users', (req, res) => {
    const query = 'SELECT * FROM users';
    connection.query(query, (err, results) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});

// 에러 핸들링 미들웨어
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

// 서버 실행
app.listen(app.get('port'), () => {
    console.log('Express server listening on port ' + app.get('port'));
});